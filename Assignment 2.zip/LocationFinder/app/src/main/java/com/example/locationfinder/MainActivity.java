package com.example.locationfinder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import java.util.Locale;
import java.util.List;
import android.location.LocationListener;
import android.location.LocationManager;

public class MainActivity extends AppCompatActivity {

    AddressDatabase AddressDatabase;
    private Button searchButton, addButton,updateButton;
    private EditText etLat, etLong, etAdd;
    Location loc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        searchButton = (Button) findViewById(R.id.searchBtn);
        addButton = (Button) findViewById(R.id.addBtn);
        updateButton = (Button) findViewById(R.id.updateBtn);
        etLat = (EditText) findViewById(R.id.etLatitude);
        etLong = (EditText) findViewById(R.id.etLongitude);
        etAdd = (EditText) findViewById(R.id.etAddress);
        AddressDatabase = new AddressDatabase(this);


        LocationManager locMan = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double la = Double.parseDouble(etLat.getText().toString());
                String strla = etLat.getText().toString();

                double lo = Double.parseDouble(etLong.getText().toString());
                String strlo = etLong.getText().toString();

                try {
                    Geocoder gc = new Geocoder(MainActivity.this, Locale.getDefault());
                    List<Address> addresses = gc.getFromLocation(la, lo,1);
                    String address = addresses.get(0).getAddressLine(0);

                    if(etLat.length() != 0 & etLong.length() != 0){
                        insertInfo(address, strla, strlo);
                        etLat.setText("");
                        etLong.setText("");
                        etAdd.setText(address);
                        //etAdd.setText("");
                    }
                    else{
                        msg("Insert info Failed!");
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }


            }
        });

    }



    public void insertInfo(String add, String lati, String longi){
        boolean insertdata = AddressDatabase.addInfo(add, lati, longi);

        if(insertdata){
            msg("Successful");
        }
        else{
            msg("Unsuccessful!");
        }

    }

    private void msg(String note) {
        Toast.makeText(this, note, Toast.LENGTH_SHORT).show();
    }
}