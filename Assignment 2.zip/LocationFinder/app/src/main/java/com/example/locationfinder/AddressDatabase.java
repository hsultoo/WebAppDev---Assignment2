package com.example.locationfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;
import android.util.Log;

import androidx.annotation.Nullable;

public class AddressDatabase extends SQLiteOpenHelper{

    private static final String TAG = "AddressDatabase";
    private static final String TABLE_NAME = "addressInfo";
    private static final String COL1 = "id";
    private static final String COL2 = "address";
    private static final String COL3 = "latitude";
    private static final String COL4 = "longitude";

    public AddressDatabase(@Nullable Context context) {
        super(context, TABLE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COL2 + " TEXT, " + COL3 + " TEXT, " + COL4 + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addInfo(String address, String latitude, String longitude){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL2, address);
        cv.put(COL3, latitude);
        cv.put(COL4, longitude);

        Log.d(TAG, "addInfo: Adding " + address + ", " + latitude + " and " + longitude + " to " + TABLE_NAME);

        long success = db.insert(TABLE_NAME, null, cv);

        if (success == -1){
            return false;
        }
        else{
            return true;
        }

    }

}
